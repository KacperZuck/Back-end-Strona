<?php

use MongoDB\BSON\ObjectID;


function get_db()
{
    $mongo = new MongoDB\Client(
        "mongodb://localhost:27017/wai",
        [
            'username' => 'wai_web',
            'password' => 'w@i_w3b',
        ]);

    $db = $mongo->wai;

    return $db;
}

function uploadFiles($photo, $watermark, $author, $title){
    $upload_dir = '/var/www/dev/src/web/images/';
    
    $file = $_FILES['photo'];
    $file_name = basename($file['name']);
    $target = $upload_dir . $file_name;
    $tmp_path = $file['tmp_name'];

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $file_name = $_FILES['photo']['name'];
    $mime_type = finfo_file($finfo, $tmp_path);  
    
    
    if ($mime_type === 'image/png' || $mime_type === 'image/jpeg') {
        $maxFileSize = 1024 * 1024; // 1 MB
        $fileSize = $_FILES['photo']['size'];

        if ($fileSize > $maxFileSize) {
            die("Błąd: Rozmiar pliku przekracza 1 MB");
        }
        else{

            $db = get_db();
            $existingPhoto = $db->photos->findOne(['name' => $file_name]);

            if ($existingPhoto) {
                echo "Plik o nazwie $file_name już istnieje w bazie danych. Nie dodawano ponownie.\n";
            } else {
                if (move_uploaded_file($tmp_path, $target)) {
                    echo "Upload przebiegł pomyślnie!\n";

                    $photo = [
                        'name' => $file_name,
                        'author' => $author,
                        'title' => $title,
                    ];

                    $fileInfo = pathinfo($file_name);
                    $extension = strtolower($fileInfo['extension']);

                    if ($extension === 'png' || $extension === 'jpg') {
                       
                        $db->photos->insertOne($photo);
                    } else {
                        echo "Błąd: Nieprawidłowe rozszerzenie pliku";
                    }


                    addWatermark($target, $watermark);
                    Miniatura($target, 200, 125);

                } else {
                    echo "Błąd: Upload nie przebiegł pomyślnie!\n";
                }
            }
        }
    }
    else{
        echo 'Błąd: Niepoprawny format\n';
    }
}

function addWatermark($target, $watermark){
    $image_info = getimagesize($target);
    $image_type = $image_info[2];

    if ($image_type == IMAGETYPE_JPEG) {
        $image = imagecreatefromjpeg($target);
    } elseif ($image_type == IMAGETYPE_PNG) {
        $image = imagecreatefrompng($target);
    }

    $font_size = 12;
    $text_color = imagecolorallocate($image, 255, 255, 255); // Biały kolor tekstu

    $font_file='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';

    $image_width = imagesx($image);
    $image_height = imagesy($image);
    $text_box = imagettfbbox($font_size, 0, $font_file, $watermark);
    $text_width = $text_box[2] - $text_box[0];
    $text_height = $text_box[1] - $text_box[7];
    $x = ($image_width - $text_width) / 2;
    $y = ($image_height + $text_height) / 2;

    imagettftext($image, $font_size, 0, $x, $y, $text_color, $font_file, $watermark);

    if ($image_type == IMAGETYPE_JPEG) {
        $watermarkPath = pathinfo($target, PATHINFO_DIRNAME) . '/watermark_' . pathinfo($target, PATHINFO_FILENAME) . '.jpg';
    } elseif ($image_type == IMAGETYPE_PNG) {
        $watermarkPath = pathinfo($target, PATHINFO_DIRNAME) . '/watermark_' . pathinfo($target, PATHINFO_FILENAME) . '.png';
    }
    imagejpeg($image, $watermarkPath);
}

function miniatura($target, $width, $height ){
    $image_info = getimagesize($target);
    $image_type = $image_info[2];

    if ($image_type == IMAGETYPE_JPEG) {
        $image = imagecreatefromjpeg($target);
    } elseif ($image_type == IMAGETYPE_PNG) {
        $image = imagecreatefrompng($target);
    }
    $thumbnail = imagecreatetruecolor($width, $height);

    $image_width = imagesx($image);
    $image_height = imagesy($image);

    imagecopyresampled($thumbnail, $image, 0, 0, 0, 0, $width, $height, $image_width, $image_height);
    
    if ($image_type == IMAGETYPE_JPEG) {
        $thumbnailPath = pathinfo($target, PATHINFO_DIRNAME) . '/thumbnail_' . pathinfo($target, PATHINFO_FILENAME) . '.jpg';
    } elseif ($image_type == IMAGETYPE_PNG) {
        $thumbnailPath = pathinfo($target, PATHINFO_DIRNAME) . '/thumbnail_' . pathinfo($target, PATHINFO_FILENAME) . '.png';
    }

    imagejpeg($thumbnail, $thumbnailPath);
}

function getPhotosPage($pageNumber, $pages)
{
    $db = get_db();
    $cursor = $db->photos->find([], ['skip' => ($pageNumber - 1) * $pages, 'limit' => $pages]);

    return $cursor;
}

function registerUser($email, $login, $password) {

    $hash = password_hash($password, PASSWORD_DEFAULT);
    
    if (password_verify($password, $hash)) {
        
        echo 'Poprawne hasło. ';

        $db = get_db();
        $user = $db->users->findOne(['login' => $login]);
                
        if ($user === null){
            $db->users->insertOne([
                'email' => $email,
                'login' => $login,
                'password' => $hash,
            ]);
            echo "Użytkonik został zapisany";
        }
        else{
            echo "Podany login jest już zajęty, podaj inny";
        }
    } else {
    echo 'Niepoprawne hasło';
    }
}
function verifyUser($login, $password) {
    
    $db = get_db();
    $user = $db->users->findOne(['login' => $login]);

    if ($user !== null && password_verify($password, $user['password'])) {
        
        $_SESSION['user_id'] = $user['_id'];

        echo "Zalogowano poprawnie ";
            
    } else {
        echo "Błędny login lub hasło";
    }
}
function ZapisanePhotos(&$model){
    
    $db = get_db();
    $selectedPhotos= [];
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_selected'])) {
        $_SESSION['selected_photos'] = $_POST['selected_photos'] ?? [];
    }

    $cursor = $db->photos->find();
    
    foreach ($cursor as $photo) {
        if (in_array($photo['_id'], $_SESSION['selected_photos'] ?? [])) {
            $selectedPhotos[] = $photo;
        }
    }
    return $selectedPhotos;
}
