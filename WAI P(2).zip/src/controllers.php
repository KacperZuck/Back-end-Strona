
<?php

require_once 'business.php';

function upload(&$model)
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $result= uploadFiles($_FILES['photo'], $_POST['watermark'], $_POST['author'], $_POST['title']);
        $model['messages']=$result;    
    }
    
    return 'upload_vw';
}
function Galeria(&$model)
{   
    $pages = 5;
    $pageNumber = 1;

    if (isset($_GET['page'])) {
        $pageNumber = $_GET['page'];
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_selected'])) {
        $_SESSION['selected_photos'] = $_POST['selected_photos'] ?? [];
    }

    $model['photos'] = getPhotosPage($pageNumber, $pages);
    $model['pages'] = $pages;

    return 'Main_vw';
}
// login
function login(&$model){
    if($_SERVER['REQUEST_METHOD']==='POST'){
        if( isset($_POST['login']) && isset($_POST['password']) ){

            $result=verifyUser($_POST['login'], $_POST['password']);
            $model['loginMessage']=$result;
        }
    }
    return 'login_vw';
}
// rejestracja 
function register(&$model){
    if($_SERVER['REQUEST_METHOD']==='POST'){
        if( isset($_POST['email']) && isset($_POST['login']) && isset($_POST['password']) && isset($_POST['repeat_password']) ){

            if ($_POST['password'] === $_POST['repeat_password']){
               
                $result= registerUser($_POST['email'], $_POST['login'], $_POST['password']);
                $model['registerInfo']=$result;
            }   
            else{
                $messages[] = "Hasła nie są identyczne, sprawdz ich dokładność.";
                return $messages;
            }
        }
    }
    return 'register_vw';
}
function logout(&$model){
    
    session_destroy();

    session_unset();
    $_SESSION = [];

    return 'logout_vw';
}
function zapisane(&$model) {
    $pages = 5;
    $pageNumber = 1;

    if (isset($_GET['page'])) {
        $pageNumber = $_GET['page'];
    }

    $selectedPhotos = [];
    $selectedPhotos = ZapisanePhotos($model);

    $model['photos'] = $selectedPhotos;
    $model['pages'] = $pages;

    return 'zapisane_vw';
}

function UsunZaznaczone(&$model)
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_selected'])) {
        $selectedPhotos = $_POST['selected_photos'] ?? [];

        $_SESSION['selected_photos'] = array_diff($_SESSION['selected_photos'], $selectedPhotos);
    }

    $pages = 5;
    $pageNumber = 1;

    if (isset($_GET['page'])) {
        $pageNumber = $_GET['page'];
    }

    $selectedPhotos = [];
    $selectedPhotos = ZapisanePhotos($model);
    
    $model['photos'] = $selectedPhotos;
    $model['pages'] = $pages;

    return 'zapisane_vw';
}
// funkcja do czyszczenia bazy zdjęć 
function removeAllDocuments()
{
    $db = get_db();
    
    // Usunięcie wszystkich dokumentów z kolekcji 'photos'
    $result = $db->photos->deleteMany([]);
    
    // Sprawdzenie, czy operacja zakończyła się sukcesem
    if ($result->getDeletedCount() > 0) {
        echo "Usunięto wszystkie dokumenty z kolekcji 'photos'.\n";
    } else {
        echo "Nie udało się usunąć dokumentów z kolekcji 'photos'.\n";
    }
}
?>


