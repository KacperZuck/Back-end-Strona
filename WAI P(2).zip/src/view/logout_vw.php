<div id="logout">
    <br/>
    <a> Wylogowano pomyślnie </a><br/>
    <form method="post" action="Galeria">
        <button type="submit">Powrót</button>
    </form>
</div>
   