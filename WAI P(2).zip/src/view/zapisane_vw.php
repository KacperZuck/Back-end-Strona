<div id="zapisane">
    <br>
<form method="post" action="UsunZaznaczone">
        <a> Galerai zapisanych zdjęć </a><br><br>
    <?php for ($i = 1; $i <= $pages; $i++): ?>
            <a href="zapisane?page=<?php echo $i; ?>"><?php echo $i; ?></a>
        <?php endfor; ?>
        <br/>
        <tbody>
            <?php 
            if(count($photos)): ?> 
                <?php foreach ($photos as $photo): ?>
                <tr>
                    <td>
                        <a href="images/watermark_<?php echo $photo['name'] ?>" type="image/jpeg">
                            <img src="images/thumbnail_<?php echo $photo['name'] ?>" alt="<?php echo $photo['name']; ?>" type="image/jpeg"><br/>
                        </a>
                    </td>
                    <td>
                        nazwa: <?php echo $photo['name']; ?><br/>
                    </td>
                    <td>
                        Autor: <?php echo $photo['author']; ?><br/>
                    </td>
                    <td>
                        Tytuł: <?php echo $photo['title']; ?><br/>
                    </td>
                    <td>
                        <input type="checkbox" name="selected_photos[]" value="<?= $photo['_id'] ?>" <?php echo (in_array($photo['_id'], $_SESSION['selected_photos'] ?? [])) ? '' : 'checked'; ?> ><br/>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Brak zdjęć do wyświetlenia.</p>
            <?php endif; ?>
        </tbody><br>
        
        <button type="submit" name="delete_selected">Usuń zaznaczone zdjęcia z zapamiętanych</button><br>
        </form>
        <br> 
    <form method="post" action="Galeria">
        <button type="submit">Powrót</button>
    </form>
</div>