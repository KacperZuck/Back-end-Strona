
<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
        <title>Strona Testowa</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0" >
        <link rel="stylesheet" href="static/css/">
    </head>
    <body>
        <?php
            if(isset($_SESSION['user_id'])){
                echo '<a href="logout"> Wyloguj</a><br/>';
            }
            else{
                echo 
                    '<a href="register"> Zarejestruj się</a><br/>
                    <a href="login"> Zaloguj się</a><br/>';
            }
        ?>
        <a href="upload"> Udostępnij zdjęcie</a><br/>
        <a href="zapisane"> Zapisane zdjęcia</a><br/><br/>
        
        <?php for ($i = 1; $i <= $pages; $i++): ?>
            <a href="Galeria?page=<?php echo $i; ?>"><?php echo $i; ?></a>
        <?php endfor; ?>
        <br/>
        <form method="post" action="Galeria">
        <tbody>
            <?php 
            if(count($photos)): ?>
                <?php foreach ($photos as $photo): ?>
                <tr>
                    <td>
                        <a href="images/watermark_<?php echo $photo['name'] ?>" type="image/jpeg">
                            <img src="images/thumbnail_<?php echo $photo['name'] ?>" alt="<?php echo $photo['name']; ?>" type="image/jpeg"><br/>
                        </a>
                    </td>
                    <td>
                        nazwa: <?php echo $photo['name']; ?><br/>
                    </td>
                    <td>
                        Autor: <?php echo $photo['author']; ?><br/>
                    </td>
                    <td>
                        Tytuł: <?php echo $photo['title']; ?><br/>
                    </td>
                    <td>
                        <input type="checkbox" name="selected_photos[]" value="<?= $photo['_id'] ?>" <?php echo (in_array($photo['_id'], $_SESSION['selected_photos'] ?? [])) ? 'checked' : ''; ?>><br/>
                    </td>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Brak zdjęć do wyświetlenia.</p>
            <?php endif; ?>
        </tbody><br>
            <button type="submit" name="save_selected">Zapamiętaj wybrane</button>
        </form> 
        <br>
    </body>
</html>