
<!DOCTYPE html>
<html>
    <head>
    <title>Edycja</title>
    <link rel="stylesheet" href="static/css/styles.css"/>
    </head>
    <body>
        <form method="post">
            <label>
                <span>Nazwa sportowca:</span>
                <input type="text" name="name" value="<?= $Galeria['name'] ?>" required/>
            </label>
            <label>
                <span>Cena:</span>
                <input type="text" name="Sport" value="<?= $Galeria['Sport'] ?>" required/>
            </label>
            <label>
                <span>Wybierz plik (PNG lub JPG, maks. 1 MB):</span>
                <input type="file" name="file" accept=".png, .jpg" value="<?= $Galeria['file'] ?>" required>
            </label>
        
            <input type="hidden" name="id" value="<?= $Galeria['_id'] ?>">
            <input type="submit" value="Prześlij">
        </form> 
    </body>
</html>