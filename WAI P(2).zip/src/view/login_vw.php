<div id="login">
       <form method="post">
              Login: 
              <input type="text" name="login" required><br>
              Hasło: 
              <input type="password" name="password" required><br><br>
              <input type="submit" value="Zaloguj">
       </form> 
       <form method="post" action="Galeria">
              <button type="submit">Powrót</button>
       </form>
</div>
   