
<!DOCTYPE html>
<html>
<head>
    <title>Rejestracja</title>
    <link rel="stylesheet" href="static/css/styles.css"/>
</head>
<body>

<div id="register">
    <form method="post">
        <label>
            Adres e-mail: 
            <input type="email" name="email" required><br><br>
            Login: 
            <input type="text" name="login" required><br><br>
            Hasło: 
            <input type="password" name="password" required><br><br>
            Powtórz hasło: 
            <input type="password" name="repeat_password" required><br><br>

            <input type="submit" value="Zarejestruj">
    </form> 
</div>
    <form method="post" action="Galeria">
        <button type="submit">Powrót</button>
    </form>
</body>
</html>



