<!-- ewentualnie doctype -->
<div id="upload">
    <form method="post" enctype="multipart/form-data">
        <label>
            <span>Autor:</span>
            <input type="text" name="author"/>
            <br/>
        </label>
        <label>
            <span>Tytul:</span>
            <input type="text" name="title"/>
            <br/>
        </label>
        <label>
            <span>Znak wodny:</span>
            <input type="text" name="watermark" required/>
            <br/><br/>
        </label>
        <label>
            <span>Wybierz plik (PNG lub JPG, maks. 1 MB):</span>
            <br/>
            <input type="file" name="photo" accept=".png, .jpg" required> 
            <br/><br/>
        </label>

        <input type="submit" value="Prześlij"><br/>
    </form>
    <form method="post" action="Galeria">
        <button type="submit">Powrót</button>
    </form>
</div>
