<?php

$routing = [
    '/' => 'Galeria',
    '/Galeria' => 'Galeria',
    '/upload' => 'upload',
    '/login' => 'login',
    '/register' => 'register',
    '/logout' => 'logout',
    '/main' => 'main',
    '/zapisane'=> 'zapisane',
    '/UsunZaznaczone'=> 'UsunZaznaczone',
];